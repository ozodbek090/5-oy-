const num1 = prompt ("ismigizni kiriting  VA  familigizni kiriting");
const num2 = +prompt ("yoshgizni kiriting");
const num3 = prompt ("yoqtirgan fanigizni yozig");
const num4 = prompt ("yoqtirgan tumanizni kiriting");
const num5 = alert ("raxmat kiritkaushn");




console.log(`Ism va Familiea:`,num1);
console.log(`Yosh:`,num2);
console.log(`Yoqtirgan fan:`,num3);
console.log(`Yoqtirgan manzili:`,num4);


